int main() {
	int a,b,c,sink,source;

	// read source from input
	if (a > 0)
		b = source;
	else
		c = b;

	sink = c;
}
